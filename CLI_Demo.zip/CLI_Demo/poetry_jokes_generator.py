"""
Poetry and Jokes Generator
A console application that generates short poems or jokes based on user-selected moods and themes.
"""

import sys

# Data structures to store poems and jokes
# Structure: [mood][theme]
POEMS = {
    "Happy": {
        "Nature": "Golden sun warms the green trees,\nSoft whispers ride the gentle breeze,\nFlowers bloom in a bright display,\nBirds sing songs to greet the day,\nJoy flows through the morning ease.",
        "Love": "Two hearts beat in a steady rhyme,\nThrough the twisting paths of time,\nLaughter echoes in the air,\nFound a love beyond compare,\nA mountain we will always climb.",
        "Friendship": "Side by side through thick and thin,\nA helping hand where we begin,\nShared secrets and a million smiles,\nBridging all the many miles,\nTrue friends are where the joys come in.",
        "Success": "The peak is reached with head held high,\nUnderneath the vast blue sky,\nHard work pays in sweet reward,\nStrength found in a common chord,\nWatch the golden banners fly."
    },
    "Sad": {
        "Nature": "Grey clouds hide the weeping sun,\nDaylight fades when day is done,\nFalling leaves upon the floor,\nWinter knocks at every door,\nSilent streams have ceased to run.",
        "Love": "A hollow space where warmth once dwelled,\nStories that will go unspelled,\nFaded photos on the wall,\nShadows stretching through the hall,\nHearts that once together swelled.",
        "Friendship": "An empty chair at the old table,\nA bond that proved to be unstable,\nWords left hanging in the cold,\nStories that remain untold,\nFading like a distant fable.",
        "Success": "The prize is held with heavy hand,\nAcross a lonely, barren land,\nVictory feels like hollow glass,\nWatching all the seasons pass,\nBuilt upon the shifting sand."
    },
    "Funny": {
        "Nature": "A squirrel stole my favorite snack,\nI want my crunchy crackers back,\nHe winked at me and climbed a tree,\nAs fast as any tail could be,\nNow I'm the one who's off the track.",
        "Love": "I wrote a poem for my cat,\nWho wore a giant purple hat,\nHe looked at me with deep disdain,\nThen ran out in the pouring rain,\nI guess our love fell rather flat.",
        "Friendship": "My best friend tried to bake a cake,\nOh, what a mess that they did make,\nThe kitchen looks like snowy hills,\nWe're covered in some flour spills,\nFor goodness and for stomach's sake.",
        "Success": "I finally reached the top today,\nBut then the ladder blew away,\nI'm stuck up here with just a view,\nI don't know what I'm meant to do,\nExcept to hope and loudly pray."
    },
    "Motivational": {
        "Nature": "The mighty oak from acorns grow,\nThough the winter winds may blow,\nDeep roots hold against the storm,\nKeeping spirit bright and warm,\nForward is the way to go.",
        "Love": "Kindness is the strongest force,\nSetting us upon the course,\nTo heal the world with every act,\nBuilding up a holy pact,\nDrawing from a deep, pure source.",
        "Friendship": "Together we can move the earth,\nShowing all what we are worth,\nUnity in every stride,\nWith our passion as our guide,\nGiving hope a brand new birth.",
        "Success": "Believe in what you're meant to be,\nSet your inner spirit free,\nEvery step is progress made,\nDo not let your courage fade,\nYou're the master of the sea."
    }
}

JOKES = {
    "Happy": {
        "Nature": "Why are trees so happy? Because they always get to 'leaf' their worries behind!",
        "Love": "Why did the two birds fall in love? It was 'tweet' at first sight!",
        "Friendship": "What did the happy flower say to its best friend? 'I'm blooming glad we're friends!'",
        "Success": "What do you call a successful sun? A 'bright' achiever!"
    },
    "Sad": {
        "Nature": "Why was the cloud so sad? It was feeling a bit under the weather.",
        "Love": "What did the sad lightbulb say to its partner? 'I'm just not feeling very bright lately.'",
        "Friendship": "Why did the sad pencil go to its friend? It felt like it had no point anymore.",
        "Success": "Why did the successful man cry? Because he realized he'd reached the top and forgot his lunch."
    },
    "Funny": {
        "Nature": "What kind of tree fits in your hand? A palm tree!",
        "Love": "Are you a carbon sample? Because I want to date you!",
        "Friendship": "What's a pirate's favorite kind of friend? A 'matey'!",
        "Success": "I used to be a baker, but I couldn't make enough 'dough' to be successful."
    },
    "Motivational": {
        "Nature": "What did the mountain say to the climber? 'You're peaking my interest!'",
        "Love": "Why did the heart go to the gym? To become a 'strong' lover!",
        "Friendship": "Why are friends like stars? You don't always see them, but you know they're always shining!",
        "Success": "Why did the student bring a ladder to school? Because they wanted to reach higher education!"
    }
}

def display_menu():
    """Displays the main menu options."""
    print("\n" + "="*30)
    print(" POETRY AND JOKES GENERATOR ")
    print("="*30)
    print("1. Poetry")
    print("2. Joke")
    print("3. Exit")
    print("-" * 30)

def get_mood():
    """Prompts user to select a mood and returns the validated choice."""
    moods = ["Happy", "Sad", "Funny", "Motivational"]
    while True:
        print("\nSelect a Mood:")
        for i, mood in enumerate(moods, 1):
            print(f"{i}. {mood}")
        
        choice = input("Enter choice (1-4): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= 4:
            return moods[int(choice) - 1]
        print("Invalid choice. Please enter a number between 1 and 4.")

def get_theme():
    """Prompts user to select a theme and returns the validated choice."""
    themes = ["Nature", "Love", "Friendship", "Success"]
    while True:
        print("\nSelect a Theme:")
        for i, theme in enumerate(themes, 1):
            print(f"{i}. {theme}")
        
        choice = input("Enter choice (1-4): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= 4:
            return themes[int(choice) - 1]
        print("Invalid choice. Please enter a number between 1 and 4.")

def generate_poem(mood, theme):
    """Retrieves and displays a poem based on mood and theme."""
    poem = POEMS.get(mood, {}).get(theme, "Poem not found.")
    print("\n" + "*"*30)
    print(f" {mood.upper()} {theme.upper()} POEM ")
    print("*"*30)
    print(poem)
    print("*"*30)

def generate_joke(mood, theme):
    """Retrieves and displays a joke based on mood and theme."""
    joke = JOKES.get(mood, {}).get(theme, "Joke not found.")
    print("\n" + "*"*30)
    print(f" {mood.upper()} {theme.upper()} JOKE ")
    print("*"*30)
    print(joke)
    print("*"*30)

def main():
    """Main function to run the application loop."""
    while True:
        display_menu()
        choice = input("Choose an option (1-3): ").strip()

        if choice == "1":
            mood = get_mood()
            theme = get_theme()
            generate_poem(mood, theme)
        elif choice == "2":
            mood = get_mood()
            theme = get_theme()
            generate_joke(mood, theme)
        elif choice == "3":
            print("\nThank you for using the Poetry and Jokes Generator! Goodbye!")
            break
        else:
            print("Invalid selection. Please choose 1, 2, or 3.")

if __name__ == "__main__":
    main()
