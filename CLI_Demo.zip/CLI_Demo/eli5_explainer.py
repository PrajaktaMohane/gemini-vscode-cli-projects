"""
Explain Like I'm 5 (ELI5) - Console Application
This application simplifies complex topics and text for a 5-year-old to understand.
"""

import sys

# Sample data for topics and text explanations
TOPIC_EXPLANATIONS = {
    "Artificial Intelligence": {
        "explanation": [
            "AI is like a robot brain that learns how to do things.",
            "It looks at lots of pictures or words to understand patterns.",
            "Just like you learn to recognize a cat, the computer learns too!"
        ],
        "example": "Like a toy that can learn your favorite game and play it with you."
    },
    "Gravity": {
        "explanation": [
            "Gravity is an invisible glue that pulls everything toward the ground.",
            "It's why you don't float away into space when you jump.",
            "Everything in the world has a little bit of this pull."
        ],
        "example": "When you drop a ball, gravity is the hand that pulls it down to the floor."
    },
    "Blockchain": {
        "explanation": [
            "Imagine a digital notebook that everyone can see but no one can erase.",
            "Each page is locked to the one before it with a special seal.",
            "It helps people trust each other when they trade things online."
        ],
        "example": "Like a shared sticker book where everyone knows exactly who has which sticker."
    },
    "Python Functions": {
        "explanation": [
            "A function is like a recipe in a cookbook.",
            "Whenever you want to make that dish, you just follow the recipe.",
            "In coding, it's a way to save steps so you don't have to write them again and again."
        ],
        "example": "Like a 'Clean Room' button that does all the tidying for you whenever you press it."
    }
}

TEXT_SAMPLES = {
    "Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize foods from carbon dioxide and water.": {
        "simple": "Plants eat sunshine to make their own food.",
        "example": "Just like you eat snacks to grow big and strong, plants use light!"
    },
    "The stock market is a complex system where shares of publicly held companies are issued, bought, and sold.": {
        "simple": "It's a giant store where people buy tiny pieces of big companies.",
        "example": "Imagine buying a tiny piece of a toy store so you get a little bit of their money when they sell toys."
    }
}

def format_output(title, content):
    """Formats the output with clear headings and separators."""
    print("\n" + "=" * 50)
    print(f" {title.upper()} ")
    print("=" * 50)
    print(content)
    print("=" * 50 + "\n")

def display_menu():
    """Displays the main menu options."""
    print("--- Explain Like I'm 5 ---")
    print("1. Explain a line of text")
    print("2. Explain a topic")
    print("3. View examples")
    print("4. Exit")
    print("-" * 26)

def explain_text():
    """Asks for a complex sentence and provides a simple explanation."""
    print("\n[Explain a line of text]")
    text = input("Paste a difficult sentence or paragraph: ").strip()
    
    if not text:
        print("Oops! You didn't enter any text.")
        return

    # Check if we have a sample for this specific text
    if text in TEXT_SAMPLES:
        result = TEXT_SAMPLES[text]
        output = f"Simple: {result['simple']}\n\nExample: {result['example']}"
    else:
        # Generic 'simplification' logic for unknown text
        output = (
            "That sounds like a big thought! To make it simple:\n"
            f"'{text[:30]}...' basically means something is happening in a special way.\n\n"
            "Try to think of it like a game with simple rules!"
        )
    
    format_output("Simplified Text", output)

def explain_topic():
    """Asks for a topic and provides a simplified explanation."""
    print("\n[Explain a topic]")
    topic = input("Enter a topic (e.g., Gravity, AI, Blockchain): ").strip().title()
    
    if not topic:
        print("Please enter a topic name.")
        return

    if topic in TOPIC_EXPLANATIONS:
        data = TOPIC_EXPLANATIONS[topic]
        points = "\n".join([f"• {p}" for p in data['explanation']])
        output = f"{points}\n\nReal-life Example: {data['example']}"
        format_output(f"Topic: {topic}", output)
    else:
        # If topic is not in our dictionary
        output = (
            f"I haven't learned about '{topic}' yet!\n"
            "But usually, complex things are just many simple things put together.\n"
            "Try searching for 'Gravity' or 'Artificial Intelligence'!"
        )
        format_output("Unknown Topic", output)

def show_examples():
    """Shows a few sample topics and their explanations."""
    output = "Here are some things I can explain:\n\n"
    for topic in TOPIC_EXPLANATIONS.keys():
        output += f"- {topic}\n"
    
    output += "\nI also know about complex sentences like 'Photosynthesis...'"
    format_output("Sample Topics", output)

def main():
    """Main application loop."""
    print("Welcome to 'Explain Like I'm 5'!")
    print("I help make big ideas easy to understand.\n")
    
    while True:
        display_menu()
        choice = input("What would you like to do? (1-4): ").strip()
        
        if choice == '1':
            explain_text()
        elif choice == '2':
            explain_topic()
        elif choice == '3':
            show_examples()
        elif choice == '4':
            print("\nGoodbye! Stay curious like a 5-year-old! 🚀")
            break
        else:
            print("\n[!] Invalid choice. Please pick a number between 1 and 4.")

if __name__ == "__main__":
    main()
