"""
Movie / Cricket Trivia Bot
A fun CLI application to test your knowledge in Movies and Cricket.
"""

# Trivia data stored in a dictionary of lists
TRIVIA_DATA = {
    "Movies": [
        {"question": "Who directed the 2010 film 'Inception'?", "answer": "Christopher Nolan"},
        {"question": "What is the highest-grossing film of all time (as of 2024)?", "answer": "Avatar"},
        {"question": "Which actor played the character Jack Sparrow in 'Pirates of the Caribbean'?", "answer": "Johnny Depp"},
        {"question": "In which 1994 film does Tom Hanks play a man with an IQ of 75?", "answer": "Forrest Gump"},
        {"question": "What is the name of the kingdom where 'Frozen' takes place?", "answer": "Arendelle"},
        {"question": "Who played the Joker in the 2008 film 'The Dark Knight'?", "answer": "Heath Ledger"},
        {"question": "Which movie features the song 'My Heart Will Go On'?", "answer": "Titanic"},
        {"question": "What is the name of the fictional African nation in 'Black Panther'?", "answer": "Wakanda"},
        {"question": "Who directed 'Jurassic Park'?", "answer": "Steven Spielberg"},
        {"question": "Which movie won the first ever Academy Award for Best Picture?", "answer": "Wings"}
    ],
    "Cricket": [
        {"question": "Who is often referred to as the 'Master Blaster'?", "answer": "Sachin Tendulkar"},
        {"question": "Which country won the first-ever Cricket World Cup in 1975?", "answer": "West Indies"},
        {"question": "What is the maximum number of overs in a standard T20 international innings?", "answer": "20"},
        {"question": "Which ground is widely known as the 'Home of Cricket'?", "answer": "Lords"},
        {"question": "Who was the captain of India when they won the 2011 World Cup?", "answer": "MS Dhoni"},
        {"question": "What do you call it when a bowler takes three wickets in three consecutive balls?", "answer": "Hat-trick"},
        {"question": "Which country's national cricket team is nicknamed the 'Proteas'?", "answer": "South Africa"},
        {"question": "Who holds the record for the highest individual score in Test cricket (400 not out)?", "answer": "Brian Lara"},
        {"question": "What is the length of a cricket pitch in yards?", "answer": "22"},
        {"question": "Which legendary Australian leg-spinner bowled the 'Ball of the Century'?", "answer": "Shane Warne"}
    ]
}

def display_welcome():
    """Displays the welcome message and main menu."""
    print("\n" + "="*40)
    print("   WELCOME TO THE TRIVIA BOT!")
    print("="*40)
    print("Categories:")
    print("1. Movies")
    print("2. Cricket")
    print("3. Exit")

def get_feedback(score, total):
    """Returns a feedback message based on the user's score."""
    if score >= 8:
        return "Excellent! 🌟"
    elif score >= 5:
        return "Good Job! 👍"
    else:
        return "Keep Practicing! 📚"

def run_quiz(category_name, questions):
    """
    Runs the quiz for a specific category.
    Returns the final score.
    """
    score = 0
    total = len(questions)
    
    print(f"\n--- Starting {category_name} Trivia ---")
    print(f"Total Questions: {total}\n")

    for i, item in enumerate(questions, start=1):
        print(f"Question {i}: {item['question']}")
        user_answer = input("Your Answer: ").strip()
        
        if user_answer.lower() == item['answer'].lower():
            print("✅ Correct!")
            score += 1
        else:
            print(f"❌ Wrong! The correct answer was: {item['answer']}")
        print("-" * 20)

    print(f"\n{category_name} Quiz Finished!")
    print(f"Your Score: {score}/{total}")
    print(f"Feedback: {get_feedback(score, total)}")
    return score

def main():
    """Main application loop."""
    while True:
        display_welcome()
        choice = input("\nPlease choose an option (1-3): ").strip()

        if choice == '1':
            run_quiz("Movies", TRIVIA_DATA["Movies"])
        elif choice == '2':
            run_quiz("Cricket", TRIVIA_DATA["Cricket"])
        elif choice == '3':
            print("\nThanks for playing! Goodbye!")
            break
        else:
            print("\nInvalid choice. Please enter 1, 2, or 3.")
            continue

        # Ask to play again after finishing a category
        play_again = input("\nWould you like to play another round? (yes/no): ").strip().lower()
        if play_again not in ['yes', 'y']:
            print("\nThanks for playing! Goodbye!")
            break

if __name__ == "__main__":
    main()
