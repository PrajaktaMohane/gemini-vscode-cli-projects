def display_menu():
    """Displays the menu options to the user."""
    print("\n--- To-Do List Menu ---")
    print("1. Add task")
    print("2. View Tasks")
    print("3. Remove task")
    print("4. Exit")

def add_task(tasks):
    """Prompts the user to add a task and appends it to the list."""
    task = input("Enter the task: ")
    tasks.append(task)
    print(f"Task '{task}' added successfully!")

def view_tasks(tasks):
    """Displays all tasks with their corresponding numbers."""
    if not tasks:
        print("\nYour to-do list is empty.")
    else:
        print("\n--- Your Tasks ---")
        for index, task in enumerate(tasks, start=1):
            print(f"{index}. {task}")

def remove_task(tasks):
    """Prompts the user for a task number and removes it from the list."""
    view_tasks(tasks)
    if not tasks:
        return

    try:
        task_num = int(input("\nEnter the task number to remove: "))
        if 1 <= task_num <= len(tasks):
            removed_task = tasks.pop(task_num - 1)
            print(f"Task '{removed_task}' removed successfully!")
        else:
            print("Invalid task number.")
    except ValueError:
        print("Please enter a valid number.")

def main():
    """Main function to run the To-Do list application."""
    tasks = []
    while True:
        display_menu()
        choice = input("Choose an option (1-4): ")

        if choice == '1':
            add_task(tasks)
        elif choice == '2':
            view_tasks(tasks)
        elif choice == '3':
            remove_task(tasks)
        elif choice == '4':
            print("Exiting To-Do list application. Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
