"""
Study Notes Summarizer
A CLI tool to summarize notes into bullet points and extract key terms.
"""

import re
from collections import Counter

# List of common English stop words to filter out during keyword extraction
STOP_WORDS = {
    "the", "and", "a", "an", "is", "of", "to", "in", "it", "that", "on", "for", 
    "with", "as", "at", "by", "this", "be", "was", "are", "from", "or", "which",
    "the", "but", "not", "also", "very", "can", "will", "has", "have", "been",
    "their", "they", "there", "were", "what", "how", "when", "who", "whom"
}

def get_multiline_input():
    """
    Collects multiple lines of text from the user.
    Input ends when the user types 'DONE' on a new line or enters a double empty line.
    """
    print("\n[PASTE YOUR NOTES BELOW]")
    print("(Type 'DONE' or press Enter twice on an empty line to finish)")
    
    lines = []
    empty_streak = 0
    
    while True:
        line = input()
        if line.strip().upper() == "DONE":
            break
        if not line.strip():
            empty_streak += 1
            if empty_streak >= 2:
                break
        else:
            empty_streak = 0
        
        lines.append(line)
    
    return "\n".join(lines).strip()

def summarize_text(text):
    """
    Extracts the most significant sentences to form a summary.
    """
    if not text:
        return []

    # Simple sentence splitting (handles ., !, ?)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    
    # Filter out sentences that are too short (less than 15 characters)
    # as they are usually not descriptive enough for a summary.
    summary_bullets = [s.strip() for s in sentences if len(s.strip()) > 15]
    
    # If the text is very long, we only take the first few as "crisp" points
    # For this simple tool, we'll take up to 5 points.
    return summary_bullets[:5]

def extract_keywords(text):
    """
    Identifies the most frequent and meaningful words in the text.
    """
    if not text:
        return []

    # Clean the text: remove punctuation and make lowercase
    words = re.findall(r'\b\w+\b', text.lower())
    
    # Filter out stop words and numbers
    filtered_words = [w for w in words if w not in STOP_WORDS and not w.isdigit() and len(w) > 2]
    
    # Count frequencies and take the top 8
    counts = Counter(filtered_words)
    return [word for word, count in counts.most_common(8)]

def display_summary(bullets, keywords):
    """
    Prints the summary and keywords in a neat format.
    """
    print("\n" + "="*50)
    print("           ✨ NOTES SUMMARY ✨")
    print("="*50)
    
    if not bullets:
        print("\nNo significant summary points found.")
    else:
        print("\n📝 Key Points:")
        for bullet in bullets:
            print(f" • {bullet}")
            
    if not keywords:
        print("\nNo significant keywords found.")
    else:
        print("\n🏷️  Important Keywords:")
        print(" | ".join([f"#{k.upper()}" for k in keywords]))
    
    print("\n" + "="*50)

def main():
    """Main application loop."""
    print("--- Welcome to Study Notes Summarizer ---")
    
    while True:
        print("\n1. Summarize New Notes")
        print("2. Exit")
        
        choice = input("\nSelect an option (1-2): ").strip()
        
        if choice == '1':
            notes = get_multiline_input()
            
            if not notes:
                print("\n⚠️  The input was empty. Please provide some text to summarize.")
                continue
            
            bullets = summarize_text(notes)
            keywords = extract_keywords(notes)
            
            display_summary(bullets, keywords)
            
        elif choice == '2':
            print("\nGoodbye! Happy studying! 📖")
            break
        else:
            print("\nInvalid choice. Please enter 1 or 2.")

if __name__ == "__main__":
    main()
